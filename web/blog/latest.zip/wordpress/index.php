<?php 
/* Short and sweet */
define('WP_USE_THEMES', true);
require('./wp-blog-header.php');
?>